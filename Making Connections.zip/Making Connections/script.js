// Jane Doe Name Change
var x = document.querySelector(".lame_name");

function changeName(){
    x.innerHTML = 'John Deere';
}



// Increasing Decreasing Connection Number
var twoFifty = 250;
var countElement = document.querySelector(".connection_amount");


function addConnections(){
    twoFifty++;
    countElement.innerHTML = twoFifty;
}

function removeConnections(){
    twoFifty--;
    countElement.innerHTML = twoFifty;
}

function accept(){
    document.querySelector(".your_connection_names").remove();
}

function decline(){
    document.querySelector(".your_connection_names").remove();
}




// Remove connection request
function remove(){
    document.querySelector('.connection_container').remove();
}



